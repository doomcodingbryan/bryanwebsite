# Handoff: Dijkstra Route Discovery — US Map

## Overview
A full-viewport data visualization: on load, a Dijkstra single-source shortest-path search animates outward from the geographic center of the contiguous United States (Lebanon, KS) across a procedurally generated road network. As the frontier reaches each of five destination cities, the city marker highlights and its shortest path draws back to the source in red. A right-hand rail lists the destinations and fills in road distances as they are settled.

Destinations: New York NY, Ithaca NY, Santa Clara CA, Menlo Park CA, Los Angeles CA.

## About the Design Files
`dijkstra-map.html` in this bundle is a **design reference created in HTML** — a working prototype showing the intended look, motion, and algorithmic behavior. It is not production code to paste in. The task is to **recreate this design in the target codebase's existing environment** (React, Vue, Svelte, native, etc.) using its established patterns, state management, and rendering libraries. If no environment exists yet, choose an appropriate framework and implement there. The algorithm and canvas-drawing logic in the prototype are, however, a correct and complete reference implementation — port them rather than reinventing.

`modernist-styles.css` is the design system stylesheet the prototype consumes. If the target codebase already has a design system, map the tokens below onto it instead of shipping this file.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, motion timing, and layout. Recreate pixel-accurately using the codebase's existing libraries.

## Screens / Views

### Single view: Route Discovery
**Purpose:** Passive visualization that plays automatically on load; the user can replay it or reveal all five shortest paths at once.

**Layout** — `.shell`, `display:flex; flex-direction:column; height:100vh`
1. **Header** (`.nav`, `flex:none`) — full width, `padding: var(--space-3) var(--space-4)`, `border-bottom: 2px solid var(--color-divider)`.
2. **Body** (`.body`, `flex:1; display:flex; min-height:0`)
   - **Stage** (`.stage`, `flex:1; position:relative; overflow:hidden`) — four stacked `<canvas>` layers, `position:absolute; inset:0`, plus an absolutely positioned DOM overlay for markers and a status line.
   - **Rail** (`.rail`, `flex:none; width:340px; min-height:0; overflow-y:auto; border-left: 2px solid var(--color-divider)`).

### Header components
- **Brand:** 14×14px solid accent square (`#ec3013`) + "Route Discovery" in `--font-heading` (Archivo) 800, ~17px, flush left, 12px gap.
- **Meta group:** right-aligned (`margin-left:auto`), four stat blocks with 28px gaps. Each: an uppercase label (11px, `letter-spacing:.08em`, `color-mix(in srgb, var(--color-text) 60%, transparent)`) over a value in Archivo 800, 15px, `font-variant-numeric: tabular-nums`, `--color-text`.
- Labels/values: `Source / Lebanon, KS`, `Nodes / <count>`, `Edges relaxed / <count>`, `Found / n / 5`.

### Stage canvas layers (bottom to top)
All sized to the stage box × `devicePixelRatio` (capped at 2), with `ctx.setTransform(dpr,0,0,dpr,0,0)`.

1. **`c-base`** — the map, drawn once per layout.
   - Land fill: `#eae9e9` (`--color-surface`).
   - State borders: `1px`, `rgba(32,30,29,0.18)`.
   - National outline: `2px`, `rgba(32,30,29,0.55)`.
2. **`c-road`** — persistent, accumulating. Settled network edges: `lineWidth 1.1`, `lineCap round`, `rgba(32,30,29,0.32)`.
3. **`c-path`** — the shortest paths: `lineWidth 2.2`, `lineJoin/lineCap round`, `#ec3013`.
4. **`c-front`** — cleared every frame. The active frontier: partially drawn edges at `lineWidth 1.6`, `rgba(236,48,19,0.85)`; frontier tip dots `r 1.4`, `rgba(236,48,19,0.5)`; the source as a 7×7px `#ec3013` square with a breathing ring (`r = 9 + (1 - cos(t/420)) * 3`, `1px`, `rgba(236,48,19,0.35)`).

### City markers (DOM, `.marker`, `transform: translate(-50%,-50%)` at the projected pixel)
- **Dot:** 9×9px square. Unfound: `2px` border `color-mix(in srgb, var(--color-text) 35%, transparent)` on `--color-bg` fill. Found: border and fill `--color-accent`.
- **Ping rings:** two 9×9px accent-bordered squares, `scale(1)→scale(7.5)` with `opacity 1→0` over 900ms `cubic-bezier(.2,.7,.3,1)`; second ring delayed 160ms. Fires once, on found.
- **Label:** two lines. Line 1 = city name, uppercase, 11px, weight 600, `letter-spacing:.06em`; dim (`color-mix(… 45%, transparent)`) until found, then `--color-text`. Line 2 = road distance, e.g. `1,347 mi`, `--color-accent`, `opacity 0→1` over 300ms with 200ms delay on found.
- **Label offsets** (px from the dot; `align:"right"` means the block is right-aligned to the offset point, i.e. it sits to the LEFT of the dot):
  - New York NY — `[14, 2]`, align left
  - Ithaca NY — `[-14, -10]`, align right
  - Menlo Park CA — `[-16, -34]`, align right
  - Santa Clara CA — `[-16, 22]`, align right
  - Los Angeles CA — `[-16, 34]`, align right
  These offsets are tuned so the three tightly clustered West-coast labels never collide. If you reflow the map, re-check collisions.
- **Source label:** "SOURCE", 10px, `letter-spacing:.12em`, uppercase, `color-mix(… 55%, transparent)`, `translate(-50%, 14px)` under the origin square.

### Status line
Bottom-left of the stage (`left:20px; bottom:18px`), 11px uppercase `letter-spacing:.1em`, `color-mix(… 55%, transparent)`; the city name inside is `--color-accent`, weight 600. Sequence: `Building network…` → `Relaxing edges…` → `Settled <city> at <n> mi` (per find) → `Search complete — 5 of 5 destinations settled`.

### Rail
- **Section 1** — kicker "SINGLE-SOURCE SHORTEST PATH" (10px, `letter-spacing:.12em`, uppercase, `--color-accent`); h2 "Dijkstra from the geographic center" (Archivo 800, 20px, `line-height 1.15`); body paragraph 13px, `line-height 1.5`, `color-mix(… 72%, transparent)`. Padding `20px`, `border-bottom: 2px solid var(--color-divider)`.
- **Section 2** — kicker "DESTINATIONS" + a `.table`: columns are a 26px zero-padded index, the city name, and a right-aligned tabular-nums distance. Rows are ordered by settle order (nearest first). Unfound row: index and distance at ~40–45% ink, distance shown as an em dash. Found row: index turns `--color-accent`, name becomes weight 600, distance becomes `--color-text` and reads `1,347 mi`. Row rule: `1px solid var(--color-divider)`; last row no rule.
- **Actions** — `margin-top:auto`, `position:sticky; bottom:0`, `background: var(--color-bg)`, `padding:20px`, 10px gap. `Run again` = `.btn .btn-primary`; `Show paths` = `.btn .btn-secondary`. Button labels are flush left per the design system.

## Interactions & Behavior
- **On load:** fetch geometry → build network → run Dijkstra to completion → animate the reveal. Nothing is user-triggered.
- **Reveal animation:** `DURATION = 9000ms`. Frame progress `p = min(1, elapsed/DURATION)`; the reveal threshold is `th = (1 - (1-p)^1.55) * dmax`, where `dmax = max(dist[target]) * 1.06` — an ease-out so the frontier surges early and settles into the far corners.
- **Edge reveal:** each shortest-path-tree edge has `d0 = dist[parent]`, `d1 = dist[child]`. Edges are sorted by `d0`; a head pointer admits edges as `th` passes `d0`. An edge with `d1 <= th` is stroked in full onto `c-road` once and dropped from the active list; otherwise it is stroked to fraction `(th - d0) / (d1 - d0)` on `c-front` each frame.
- **Find event:** when `th >= dist[cityNode]`, the marker gets `.found` (dot fill, ping rings, distance fade-in), the rail row fills in, the Found counter increments, the status line updates, and that city's path begins drawing.
- **Path draw:** over 850ms, the chain from source to city is stroked progressively (`n = max(2, floor(chain.length * f))` vertices) onto `c-path`. All previously found paths are redrawn each frame while any is animating.
- **Run again:** clears the road/path/front canvases, resets markers and rows, restarts the clock. Base map and network are reused.
- **Show paths:** clears `c-path` and strokes all five complete paths instantly.
- **Resize:** debounced 250ms, then a full rebuild (re-projection, re-sampling, re-triangulation, re-run). Node count therefore scales with window size.
- **Hover / focus:** inherited from the design system — accent-ramp hover and pressed tints, `2px` accent `:focus-visible` ring at `2px` offset. Do not restyle.

## State Management
- `us` — `{ states: FeatureCollection, nation: Feature }`, loaded once.
- `G` — the built network: `{ w, h, pts (Float64 xy pairs), ll (lon/lat pairs), edges (sorted tree edges), dist, targets, dmax, src, o }`.
- Per-run transient: `head` (edge admission pointer), `active` (partially drawn edges), `found` count, `t0` (run start), `rev` (found cities with their path-draw start times), and per-target `done`.
- `raf` — the animation frame handle; cancelled on rebuild and on replay.
- Data fetching: one JSON request at startup (see Assets).

## Algorithm / Data Pipeline (port this as-is)
1. **Projection** — `d3.geoAlbersUsa().fitExtent([[padX, 30], [w - padX, h - 30]], nation)` where `padX = max(136, min(160, w * 0.12))`. The generous horizontal padding is what keeps the coastal labels on-canvas.
2. **Land mask** — the nation path is filled onto an offscreen canvas; a point is "on land" if its pixel alpha > 140. This is far faster than `geoContains` for thousands of samples and is exact in screen space.
3. **Sampling** — a hexagonal grid, `step = 11px`, rows offset by `step/2`, each point jittered by ±35% of step via a deterministic hash. Points off land or outside the projection domain are discarded. The source and the five cities are appended as exact nodes so their distances are distinct (Menlo Park and Santa Clara are ~25 km apart and would otherwise snap to one sample).
4. **Edges** — `d3.Delaunay` over the point set; each unique half-edge pair is kept only if its length ≤ `step * 1.9` and its midpoint is on land (this drops hull edges spanning the Gulf, the Great Lakes, and the coastline).
5. **Edge cost** — `length * (0.35 + 1.9 * field(midX, midY))`, where `field` is 3-octave value noise (periods 95 / 38 / 16 px, weights .62 / .28 / .10) built on a `sin`-hash. The noise is what makes the expansion look like roads finding routes rather than a plain circular wavefront. It is deterministic per pixel position.
6. **Dijkstra** — binary min-heap over a CSR-style adjacency (head/next/to/weight arrays), recording `dist`, `par`, the settle `order`, and a count of relaxations for the header stat.
7. **Reported distance** — great-circle length of the actual path, `Σ d3.geoDistance(ll[i-1], ll[i]) * 3958.8` miles. It is a real geodesic measurement of the found route, not a straight-line estimate.

## Design Tokens
From the Modernist design system (`modernist-styles.css`) — take these from the target codebase's equivalents where they exist.

| Token | Value | Use |
| --- | --- | --- |
| `--color-bg` | `#f3f2f2` | Page ground, marker dot fill |
| `--color-surface` | `#eae9e9` | Land fill |
| `--color-text` | `#201e1d` | Ink; canvas strokes use it at 0.18 / 0.32 / 0.55 alpha |
| `--color-accent` | `#ec3013` | Frontier, found markers, paths, kickers, primary button |
| `--color-divider` | `#201e1d` at 40% | All 2px section rules and 1px table rules |
| `--font-heading` / `--font-body` | Archivo (400 / 600 / 800) | Everything |
| `--radius-md` | `0` | Zero radius everywhere — do not round a corner |
| Spacing | `--space-2` / `--space-3` / `--space-4` | Rail and header padding |

Type scale in use: 10px (kickers/source label), 11px (meta labels, marker labels, status), 13px (body, table), 15px (meta values), 17px (brand), 20px (rail h2).

Motion: reveal 9000ms ease-out `1-(1-p)^1.55`; ping 900ms `cubic-bezier(.2,.7,.3,1)` with a 160ms second-ring delay; path draw 850ms linear; distance fade 300ms with 200ms delay.

## Assets
- **Geometry:** `https://cdn.jsdelivr.net/npm/us-atlas@3.0.1/states-10m.json` (Natural Earth / US Census derived, public domain). Alaska, Hawaii, and Puerto Rico (`id` 02, 15, 72) are filtered out and the remaining state geometries are merged with `topojson.merge` for the national outline.
- **Fallback:** `https://cdn.jsdelivr.net/npm/world-atlas@2.0.2/countries-110m.json`, USA feature only, if the primary fetch fails.
- **Libraries:** d3 7.9.0 (`d3-geo`, `d3-delaunay`) and topojson-client 3.1.0, loaded from pinned, SRI-hashed unpkg tags. Keep the pins and hashes when porting, or install the equivalent npm packages.
- **Font:** Archivo, via the design system's Google Fonts import.
- No images or icons.

## Files
- `dijkstra-map.html` — the complete prototype (markup, styles, algorithm, animation).
- `modernist-styles.css` — the design system token sheet and component classes the prototype links.
